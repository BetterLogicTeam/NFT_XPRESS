const Footer = () => {
    return ( 
        <div>
             <footer class="page-footer footer">
            <p class="mb-0">Copyright © NFT XPRESS 2022. All right reserved.</p>
        </footer>
        </div>
     );
}
 
export default Footer;