import {Dashboard} from '../../Containers'
const Home = () => {
    return ( 
        <div>
            <Dashboard />
        </div>
     );
}
 
export default Home;
